## Práctica 1
crear
X    crear -f nombre (crea archivo)
X    crear nombre funciona (crea directorio)
     
borrar
X borra archivos
X    borra directorios
X  borra directorios y archivos mezclados
X    borra varios archivos
X   imprime cwd cuando no se le pasa argumento como parámetro
borrarrec
    borra directorio con archivos dentro
X   imprime cwd cuando no se le pasa argumento como parámetro
listfich
listdir